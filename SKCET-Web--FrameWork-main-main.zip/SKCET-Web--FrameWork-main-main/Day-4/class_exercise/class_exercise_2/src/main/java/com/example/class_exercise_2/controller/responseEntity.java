package com.example.class_exercise_2.controller;

public class responseEntity<> {

}
