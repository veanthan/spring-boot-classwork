package com.example.practice_exercise_1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PracticeExercise1Application {

	public static void main(String[] args) {
		SpringApplication.run(PracticeExercise1Application.class, args);
	}

}
