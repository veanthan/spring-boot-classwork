package com.example.practice_at_home_1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PracticeAtHome1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
