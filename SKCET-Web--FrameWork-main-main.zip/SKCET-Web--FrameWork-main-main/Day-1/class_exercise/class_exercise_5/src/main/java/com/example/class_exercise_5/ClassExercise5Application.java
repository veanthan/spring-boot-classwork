package com.example.class_exercise_5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClassExercise5Application {

	public static void main(String[] args) {
		SpringApplication.run(ClassExercise5Application.class, args);
	}

}
