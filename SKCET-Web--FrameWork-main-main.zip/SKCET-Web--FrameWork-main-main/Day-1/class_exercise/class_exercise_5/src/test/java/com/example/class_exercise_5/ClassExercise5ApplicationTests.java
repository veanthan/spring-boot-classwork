package com.example.class_exercise_5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClassExercise5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
