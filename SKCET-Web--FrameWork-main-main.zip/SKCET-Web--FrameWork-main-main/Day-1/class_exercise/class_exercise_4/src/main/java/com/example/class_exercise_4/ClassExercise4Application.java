package com.example.class_exercise_4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClassExercise4Application {

	public static void main(String[] args) {
		SpringApplication.run(ClassExercise4Application.class, args);
	}

}
