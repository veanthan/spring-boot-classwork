package com.example.challenge_yourself_1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChallengeYourself1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
