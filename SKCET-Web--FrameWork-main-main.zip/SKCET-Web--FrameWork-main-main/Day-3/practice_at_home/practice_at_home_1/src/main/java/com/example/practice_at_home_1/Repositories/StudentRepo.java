package com.example.practice_at_home_1.Repositories;

public class StudentRepo {

}
