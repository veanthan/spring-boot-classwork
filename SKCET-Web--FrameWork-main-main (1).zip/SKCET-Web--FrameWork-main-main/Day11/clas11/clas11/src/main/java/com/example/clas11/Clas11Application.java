package com.example.clas11;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Clas11Application {

	public static void main(String[] args) {
		SpringApplication.run(Clas11Application.class, args);
	}

}
