package com.example.clas11.controller;

public class StudentInformationController {
    
}
