package com.example.practice_at_home_1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PracticeAtHome1Application {

	public static void main(String[] args) {
		SpringApplication.run(PracticeAtHome1Application.class, args);
	}

}
