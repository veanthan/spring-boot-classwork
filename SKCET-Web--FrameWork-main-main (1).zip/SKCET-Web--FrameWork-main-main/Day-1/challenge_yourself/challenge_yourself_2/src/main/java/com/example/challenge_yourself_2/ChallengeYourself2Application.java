package com.example.challenge_yourself_2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChallengeYourself2Application {

	public static void main(String[] args) {
		SpringApplication.run(ChallengeYourself2Application.class, args);
	}

}
